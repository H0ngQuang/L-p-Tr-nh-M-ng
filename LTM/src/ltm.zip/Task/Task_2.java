/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task;

import UDP.Product;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * je23s0tw - UDP - Object
 *
 */
public class Task_2 {

    static public void execute_task_2() {
        String Server = "203.162.10.109";
        int Server_Port = 2209;
        String studentCode = "B22DCCN759";
        String qCode = "je23s0tw";

        DatagramSocket socket = null;

        try {

            socket = new DatagramSocket();
            InetAddress address = InetAddress.getByName(Server);

            String message = ";" + studentCode + ";" + qCode;
            byte[] sendData = message.getBytes();
            socket.send(new DatagramPacket(sendData,
                    sendData.length,
                    address,
                    Server_Port));
            System.out.println("[Send]: " + message);

            byte[] receiveData = new byte[8192];
            DatagramPacket receivePacket = new DatagramPacket(
                    receiveData,
                    receiveData.length);
            socket.receive(receivePacket);
       
            String requestId = new String(receivePacket.getData(), 0, 8);

            System.out.println(receivePacket);

            ByteArrayInputStream bais = new ByteArrayInputStream(
                    receivePacket.getData(),
                    8,
                    receivePacket.getLength() - 8);
             System.out.println(bais);
            ObjectInputStream ois = new ObjectInputStream(bais);
            Product p = (Product) ois.readObject();
            ois.close();
            System.out.println(p);
            p.fixName();
            p.fixQuantity();
            System.out.println(p);
            
            ByteArrayOutputStream productBAOS = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(productBAOS);
            
            
            
            ByteArrayOutputStream finalBAOS = new ByteArrayOutputStream();
            
            finalBAOS.write(requestId.getBytes());
            oos.writeObject(p);
            oos.flush();
            finalBAOS.write(productBAOS.toByteArray());
            byte[] finalData = finalBAOS.toByteArray();
            socket.send(new DatagramPacket(
                    finalData,
                    finalData.length,
                    address,
                    Server_Port
            ));
            System.out.println(finalData);
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
                System.out.println("closed!");
            }
        }
    }
}
