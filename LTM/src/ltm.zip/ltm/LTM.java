
package ltm;

import Task.Task_2;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;


public class LTM {

     public static void main(String[] args) {
        Task_2.execute_task_2();
    }
    
}
